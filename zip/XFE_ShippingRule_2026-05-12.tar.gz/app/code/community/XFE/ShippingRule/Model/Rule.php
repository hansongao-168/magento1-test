<?php
/**
 * XFE ShippingRule Rule Model
 *
 * @category   Community
 * @package    XFE_ShippingRule
 */
class XFE_ShippingRule_Model_Rule extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('xfeshippingrule/rule');
    }

    /**
     * Save conditions after saving rule
     *
     * @return Mage_Core_Model_Abstract
     */
    protected function _afterSave()
    {
        parent::_afterSave();

        if (!$this->getId()) {
            return $this;
        }

        // Delete old condition groups and conditions (CASCADE will handle conditions)
        $oldGroups = Mage::getModel('xfeshippingrule/conditionGroup')->getCollection()
            ->addRuleFilter($this->getId());

        foreach ($oldGroups as $group) {
            $group->delete();
        }

        // Save new conditions
        $groupsData = $this->getGroupsData();
        if (is_string($groupsData)) {
            $groupsData = Mage::helper('core')->jsonDecode($groupsData);
        }

        if (!is_array($groupsData) || empty($groupsData)) {
            return $this;
        }

        $sortOrder = 0;
        foreach ($groupsData as $groupData) {
            $group = Mage::getModel('xfeshippingrule/conditionGroup');
            $group->setRuleId($this->getId());
            $group->setSortOrder($sortOrder++);
            $group->setAggregator(isset($groupData['aggregator']) ? $groupData['aggregator'] : 'all');
            $group->save();

            if (isset($groupData['conditions']) && is_array($groupData['conditions'])) {
                $condSortOrder = 0;
                foreach ($groupData['conditions'] as $conditionData) {
                    $condition = Mage::getModel('xfeshippingrule/condition');
                    $condition->setGroupId($group->getId());
                    $condition->setSortOrder($condSortOrder++);
                    $condition->setAttribute(isset($conditionData['attribute']) ? $conditionData['attribute'] : '');
                    $condition->setOperator(isset($conditionData['operator']) ? $conditionData['operator'] : '==');
                    $condition->setValue(isset($conditionData['value']) ? $conditionData['value'] : '');
                    $condition->save();
                }
            }
        }

        return $this;
    }

    /**
     * Calculate shipping fee based on order data
     *
     * @param array $orderData
     *   Keys: user_id, user_email, country_code, zip_code,
     *         package_count, package_weight, length, width, height,
     *         order_total (for percent calculation)
     * @return array ['matched' => bool, 'fee' => float, 'rule_id' => int|null]
     */
    public function calculate(array $orderData)
    {
        // Load all enabled rules
        $rules = Mage::getModel('xfeshippingrule/rule')->getCollection()
            ->addActiveFilter();

        foreach ($rules as $rule) {
            // Check package count range
            $packageCount = isset($orderData['package_count']) ? (int)$orderData['package_count'] : 1;
            $packageMin = (int)$rule->getPackageMin();
            $packageMax = $rule->getPackageMax();

            if ($packageCount < $packageMin) {
                continue;
            }
            if ($packageMax !== null && $packageCount > (int)$packageMax) {
                continue;
            }

            // Reload rule with conditions
            $rule->load($rule->getId());
            $conditionsData = $rule->getConditionsData();

            // If no conditions, rule matches by default (package range only)
            $matched = true;
            if (!empty($conditionsData)) {
                $matched = false;
                // Group logic: OR between groups
                foreach ($conditionsData as $groupData) {
                    $aggregator = isset($groupData['aggregator']) ? $groupData['aggregator'] : 'all';
                    $conditions = isset($groupData['conditions']) ? $groupData['conditions'] : array();

                    if (empty($conditions)) {
                        continue;
                    }

                    $groupMatched = $this->_matchGroup($conditions, $aggregator, $orderData);
                    if ($groupMatched) {
                        $matched = true;
                        break;
                    }
                }
            }

            if (!$matched) {
                continue;
            }

            // Calculate shipping fee
            $fee = $this->_calculateFee($rule, $orderData, $packageCount);

            return array(
                'matched' => true,
                'fee'     => $fee,
                'rule_id' => $rule->getId(),
            );
        }

        return array(
            'matched' => false,
            'fee'     => 0.0,
            'rule_id' => null,
        );
    }

    /**
     * Calculate fee for a matched rule
     *
     * @param XFE_ShippingRule_Model_Rule $rule
     * @param array $orderData
     * @param int $packageCount
     * @return float
     */
    protected function _calculateFee($rule, $orderData, $packageCount)
    {
        $shippingFee = (float)$rule->getShippingFee();

        // Billing type: per_order or per_package
        if ($rule->getBillingType() === 'per_package') {
            $shippingFee *= $packageCount;
        }

        // Load type to get calculation type
        $type = Mage::getModel('xfeshippingrule/type')->load($rule->getTypeId());
        $calculationType = $type->getCalculationType();

        switch ($calculationType) {
            case 'percent':
                $orderTotal = isset($orderData['order_total']) ? (float)$orderData['order_total'] : 0;
                $fee = $shippingFee * $orderTotal / 100;
                break;

            case 'weight':
                $packageWeight = isset($orderData['package_weight']) ? (float)$orderData['package_weight'] : 0;
                $fee = $shippingFee * $packageWeight;
                break;

            case 'fixed':
            default:
                $fee = $shippingFee;
                break;
        }

        return round($fee, 4);
    }

    /**
     * Match a group of conditions against order data
     *
     * @param array $conditions
     * @param string $aggregator all=AND, any=OR
     * @param array $orderData
     * @return bool
     */
    protected function _matchGroup(array $conditions, $aggregator, array $orderData)
    {
        if ($aggregator === 'any') {
            // OR logic: any condition matches
            foreach ($conditions as $condition) {
                if ($this->_matchCondition($condition, $orderData)) {
                    return true;
                }
            }
            return false;
        } else {
            // AND logic: all conditions must match
            foreach ($conditions as $condition) {
                if (!$this->_matchCondition($condition, $orderData)) {
                    return false;
                }
            }
            return true;
        }
    }

    /**
     * Match a single condition against order data
     *
     * @param array $condition
     * @param array $orderData
     * @return bool
     */
    protected function _matchCondition(array $condition, array $orderData)
    {
        $attribute = isset($condition['attribute']) ? $condition['attribute'] : '';
        $operator  = isset($condition['operator']) ? $condition['operator'] : '==';
        $value     = isset($condition['value']) ? $condition['value'] : '';

        if (!isset($orderData[$attribute])) {
            return false;
        }

        $subjectValue = $orderData[$attribute];

        switch ($operator) {
            case '==':
                return (string)$subjectValue === (string)$value;

            case '!=':
                return (string)$subjectValue !== (string)$value;

            case '>':
                return (float)$subjectValue > (float)$value;

            case '>=':
                return (float)$subjectValue >= (float)$value;

            case '<':
                return (float)$subjectValue < (float)$value;

            case '<=':
                return (float)$subjectValue <= (float)$value;

            case 'in':
                $values = array_map('trim', explode(',', $value));
                return in_array((string)$subjectValue, $values);

            case 'contains':
                return strpos((string)$subjectValue, (string)$value) !== false;

            case 'between':
                $parts = explode('~', $value);
                if (count($parts) !== 2) {
                    return false;
                }
                $min = (float)trim($parts[0]);
                $max = (float)trim($parts[1]);
                $subjectFloat = (float)$subjectValue;
                return $subjectFloat >= $min && $subjectFloat <= $max;

            default:
                return false;
        }
    }
}
