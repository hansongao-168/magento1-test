<?php
/**
 * Adjustment Edit Form
 *
 * @category   Community
 * @package    XFE_InvoiceAdjustment
 */
class XFE_InvoiceAdjustment_Block_Adminhtml_Adjustment_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
{
    /**
     * Prepare form
     *
     * @return XFE_InvoiceAdjustment_Block_Adminhtml_Adjustment_Edit_Form
     */
    protected function _prepareForm()
    {
        $model = Mage::registry('current_adjustment');

        $form = new Varien_Data_Form(array(
            'id'     => 'edit_form',
            'action' => $this->getUrl('*/*/save', array('id' => $this->getRequest()->getParam('id'))),
            'method' => 'post',
        ));

        $form->setUseContainer(true);
        $this->setForm($form);

        if ($model) {
            $form->setValues($model->getData());
        }

        return parent::_prepareForm();
    }
}
